module.exports = {
  tokens: "7683755576:AAFltBZ8Tu6PahWn5qRL64xZhpCjLq-jZ_0",
  owner: "6142885267",
};